package com.example.consolesampleandroid;
//C++ Unsigned 16 Bit Integer (unsigned short int) to java
public class uint16 extends UShort{

	public uint16(int value) throws NumberFormatException {
		super(value);
	}

	public int size() {
		return 2;
	}
		


}
