package com.example.consolesampleandroid;


public class xfFrame {
	
	private byte soh;
	private String id;
	private byte ctrl;
	private byte ifld;
	private byte[] memory;
	private uint16 fcs;
	
	public xfFrame() {
		soh=0;
		id= "";
		ctrl=0;
		ifld=0;
		memory= new byte[15];
		fcs=new uint16(0);
	}

	public int memorySize() {
		return memory.length;
	}
	
	public byte[] getMemory() {
		return memory;
	}

	public void setSoh(byte soh) {
		this.soh=soh;
	}

	public void setCtrl(byte ctrl) {
		this.ctrl=ctrl;
	}

	public void setId(String id) {
		this.id=id;
	}

	public void setFcs(uint16 fcs) {
		this.fcs=fcs;
	}

	public uint16 getFcs() {
		return fcs;
	}
}
