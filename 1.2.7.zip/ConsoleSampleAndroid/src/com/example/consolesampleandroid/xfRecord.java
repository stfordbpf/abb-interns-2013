package com.example.consolesampleandroid;

public class xfRecord {

	private uint16[] len;
	private byte type;
	private byte Type;
	private Register Reg;
	private uint16 nRegs;
	private uint16 unused;
	private byte[] memory; 
	private byte[] crcMem;
	
	public xfRecord() {
		len=new uint16[2];
			len[0]=new uint16(0x0e00);
			len[1]=new uint16(0xf1ff);
		type=0;
		Type=0;
		Reg=null;
		nRegs=null;
		unused=new uint16(0);
		memory=new byte[14];
		crcMem=new byte[2];
		
	}
	
	public int memorySize() {
		return memory.length;
	}

	public byte[] getMemory() {
		return memory;
	}

	public Register getReg() {
		return Reg;
	}

	public void setReg(Register reg) {
		Reg = reg;
	}

	public byte getType() {
		return Type;
	} 

	public void setType(byte VARIABLE) {
		Type = VARIABLE;
	}

	public uint16 getnRegs() {
		return nRegs;
	}

	public void setnRegs(uint16 nRegs) {
		this.nRegs = nRegs;
	}

	public uint16[] getLen() {
		return len;
	}

	public void setLen(uint16[] len) {
		this.len = len;
	}

	public byte[] getCrcMem() {
		return crcMem;
	}

}
