package com.example.consolesampleandroid;

import java.io.*;
import java.nio.*;
import java.text.DateFormat;
import java.util.*;

import android.annotation.*;
import android.app.*;
import android.bluetooth.*;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

@TargetApi(Build.VERSION_CODES.GINGERBREAD)
public class MainActivity extends Activity implements OnClickListener{
	
	private static BluetoothDevice device;
	private xfRequest[] registerList;
	private String stationID;
	private String code;
	RegisterData RegisterData; 
	xfProtocol db2Protocol;
	byte Status;
	private int numFloats=0;
	private int numInt32=0;
	float[] floatData;
	int32[] int32Data;
	
	private static int arraySize=1;
	private final int NUM_REGISTERS=17;
	Button bRun;
	Button bShare;
	TextView tvDisplayData;
	String s = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		bRun = (Button) findViewById(R.id.bRun);
		tvDisplayData = (TextView) findViewById(R.id.tvDisplayText);
		bRun.setOnClickListener(this);
		
		bShare = (Button) findViewById(R.id.bShare);
		bShare.setOnClickListener(this);
		
		registerList = new xfRequest[NUM_REGISTERS];
		
		int floatSize = Float.SIZE/8;
		
		xfRequest todayV = new xfRequest(11,7,7, arraySize, floatSize); numFloats++;
		xfRequest yesterdayV = new xfRequest(11,7,9, arraySize, floatSize); numFloats++;
		xfRequest todayUV = new xfRequest(11,7,11, arraySize, floatSize); numFloats++;
		xfRequest yesterdayUV = new xfRequest(11,7,13, arraySize, floatSize); numFloats++;
		
		xfRequest currentER = new xfRequest(11, 3, 73, arraySize, floatSize); numFloats++;
		xfRequest todayER = new xfRequest(11,3,71, arraySize, floatSize); numFloats++;
		xfRequest yesterdayER = new xfRequest(11,3,72, arraySize, floatSize); numFloats++;
		
		xfRequest currentFR = new xfRequest(11, 7, 6, arraySize, floatSize); numFloats++;
		xfRequest todayFR = new xfRequest(11,7,22, arraySize, floatSize); numFloats++;
		xfRequest yesterdayFR = new xfRequest(11,7,23, arraySize, floatSize); numFloats++;
		
		xfRequest battery = new xfRequest(7,3,5, arraySize, floatSize); numFloats++;
		xfRequest charger = new xfRequest(7,3,6, arraySize, floatSize); numFloats++;
		
		xfRequest temperature = new xfRequest(11,3,3, arraySize, floatSize); numFloats++;
		xfRequest DP = new xfRequest(11,7,0, arraySize, floatSize); numFloats++;
		xfRequest alarms = new xfRequest(11, 9, 0, arraySize, int32.sizeof()); numInt32++;
		
		xfRequest volume14 = new xfRequest(11,225,0 , 14, floatSize); numFloats+=14;
		xfRequest pressure14 = new xfRequest(11,221, 0, 14, floatSize); numFloats+=14;
		
		registerList[0]= todayV;
		registerList[1]= yesterdayV;
		registerList[2]=todayUV;
		registerList[3]=yesterdayUV;
		registerList[4]= currentER;
		registerList[5]= todayER;
		registerList[6]= yesterdayER;
		registerList[7]= currentFR;
		registerList[8]= todayFR;
		registerList[9]= yesterdayFR;
		registerList[10]= battery;
		registerList[11]= charger;
		registerList[12]= temperature;
		registerList[13]= DP;
		registerList[14] = volume14;
		registerList[15]= pressure14;
		registerList[16]= alarms; 
	}

	public void execute() {	
		RegisterData = new RegisterData(arraySize, numFloats, numInt32); //FLOAT=4, as does int32
		db2Protocol = new xfProtocol(code,stationID,registerList, RegisterData, device);
		
		Thread thread1 = new Thread(db2Protocol);
		thread1.run();
		Status=db2Protocol.finalStatus;
		showData();
	}
	
	public void showData() {
		if(Status==0) {
		/*	for(int i=0; i<RegisterData.getMemory().length; i++) {
				s+=(String.format("%02x", RegisterData.getMemory()[i]&0xff)+" ");
				tvDisplayData.setText(s);
			} */

//			String fileName = logData(RegisterData.getMemory());
//			byte[] savedData = readData(fileName);
//			tvDisplayData.setText(fileName+"\n");
			
			floatData=new float[numFloats];
			int32Data=new int32[numInt32];
			parseData(RegisterData.getMemory());
			String fileData = formatToString(floatData, int32Data);
			tvDisplayData.append(fileData);
//			writeFile(floatData, int32Data);
		} else {
			tvDisplayData.setTag("Improper Return "+Status);
			switch(Status) {
				case 102: tvDisplayData.setText(" The device received a bad xfHeader CRC.");
						break;
				case 104: tvDisplayData.setText(" The device received a bad xfRecord CRC.");
						break;
				case 106: tvDisplayData.setText(" The device received an invalid operation request.");
						break;
				case 126: tvDisplayData.setText(" Illegal register read or write.");
						break;
				case (byte) 0x81: tvDisplayData.setText(" Undefined error.");
								break;
				case (byte) 0x88: tvDisplayData.setText(" xfFrame already in use.");
								break;
				case (byte) 0x96: tvDisplayData.setText(" Invalid application slot.");
								break;
				case (byte) 251: tvDisplayData.setText(" xfLENERR");
								break;
				case (byte) 252: tvDisplayData.setText(" xfCRCERR");
								break;
				case (byte) 253: tvDisplayData.setText(" xfNAKCODE");
								break;
				case (byte) 254: tvDisplayData.setText(" xfINVALID");
								break;
				case (byte) 255: tvDisplayData.setText(" xfTIMOUT");
								break;
				default: tvDisplayData.append(Status+" Unknown error number was returned.");
				break;
			}
		}
	}
	
	private void parseData(byte[] memory) {
		int byteIndex=0;
		for(int i=0; i<RegisterData.getNumFloats(); i++) {
			floatData[i]=ByteBuffer.wrap(RegisterData.getMemory()).order(ByteOrder.LITTLE_ENDIAN).getFloat(byteIndex);
			byteIndex+=Float.SIZE/8;
		}
		for(int i=0; i<RegisterData.getNumInt32(); i++) {
			int32Data[i]=new int32(ByteBuffer.wrap(RegisterData.getMemory()).order(ByteOrder.LITTLE_ENDIAN).getInt(byteIndex));
			byteIndex+=int32.sizeof();
		}
	}

	private byte[] readData(String fileName) {
		FileInputStream fis;
		int numBytes=0;
		byte[] buffer = new byte[1024];
		try {
			fis = openFileInput(fileName);
			numBytes = fis.read(buffer);
			fis.close();
		} catch(IOException e) {
			
		}
		byte[] readBytes = new byte[numBytes];
		for(int i=0; i<numBytes; i++) {
			readBytes[i]=buffer[i];
		}
		return readBytes;
	}

	private String logData(byte[] registerData) {
		FileOutputStream fos;
		Calendar c = Calendar.getInstance();
		String fileName=stationID+","+c.get(Calendar.MONTH)+"."+c.get(Calendar.DAY_OF_MONTH)+","+c.get(Calendar.HOUR_OF_DAY)+"."+c.get(Calendar.MINUTE)+c.get(Calendar.AM_PM);
		try {
			fos = openFileOutput(fileName, Context.MODE_PRIVATE);
			fos.write(registerData);
			fos.close();
		} catch (IOException e) {
			tvDisplayData.append(e.toString());
		}
		return fileName;
	}

	private String formatToString(float[] floatData, int32[] int32Data) {
		String fileData="\n";
		fileData+="Today's Volume,"; 				fileData+=floatData[0]; fileData+="\n";
		fileData+="Yesterday's Volume,"; 			fileData+=floatData[1]; fileData+="\n";
		fileData+="Today's Uncorrected Volume,"; 	fileData+=floatData[2]; fileData+="\n";
		fileData+="Yesterday's Uncorrected Volume,"; fileData+=floatData[3]; fileData+="\n";
		fileData+="Current Energy Rate,"; 			fileData+=floatData[4]; fileData+="\n";
		fileData+="Today's Energy Rate,";			fileData+=floatData[5]; fileData+="\n";
		fileData+="Yesterday's Energy Rate,";		fileData+=floatData[6]; fileData+="\n";
		fileData+="Current Flow Rate,";				fileData+=floatData[7]; fileData+="\n";
		fileData+="Today's Flow Rate,";				fileData+=floatData[8]; fileData+="\n";
		fileData+="Yesterday's Flow Rate,";			fileData+=floatData[9]; fileData+="\n";
		fileData+="Battery Status,";				fileData+=floatData[10]; fileData+="\n";
		fileData+="Charger Status,";				fileData+=floatData[11]; fileData+="\n";
		fileData+="Temperature,"; 					fileData+=floatData[12]; fileData+="\n"; 
		fileData+="Differential Pressure,"; 		fileData+=floatData[13]; fileData+="\n";
		fileData+="Alarm Bits,"; 					fileData+=Integer.toBinaryString(int32Data[0].value);

		fileData+="Day 1 Volume,";					fileData+=floatData[14]; fileData+="\n";
		fileData+="Day 2 Volume,";					fileData+=floatData[15]; fileData+="\n";
		fileData+="Day 3 Volume,";					fileData+=floatData[16]; fileData+="\n";
		fileData+="Day 4 Volume,";					fileData+=floatData[17]; fileData+="\n";
		fileData+="Day 5 Volume,";					fileData+=floatData[18]; fileData+="\n";
		fileData+="Day 6 Volume,";					fileData+=floatData[19]; fileData+="\n";
		fileData+="Day 7 Volume,";					fileData+=floatData[20]; fileData+="\n";
		fileData+="Day 8 Volume,";					fileData+=floatData[21]; fileData+="\n";
		fileData+="Day 9 Volume,";					fileData+=floatData[22]; fileData+="\n";
		fileData+="Day 10 Volume,";					fileData+=floatData[23]; fileData+="\n";
		fileData+="Day 11 Volume,";					fileData+=floatData[24]; fileData+="\n";
		fileData+="Day 12 Volume,";					fileData+=floatData[25]; fileData+="\n";
		fileData+="Day 13 Volume,";					fileData+=floatData[26]; fileData+="\n";
		fileData+="Day 14 Volume,";					fileData+=floatData[27]; fileData+="\n";
		
		fileData+="Day 1 DP,";						fileData+=floatData[28]; fileData+="\n";
		fileData+="Day 2 DP,";						fileData+=floatData[29]; fileData+="\n";
		fileData+="Day 3 DP,";						fileData+=floatData[30]; fileData+="\n";
		fileData+="Day 4 DP,";						fileData+=floatData[31]; fileData+="\n";
		fileData+="Day 5 DP,";						fileData+=floatData[32]; fileData+="\n";
		fileData+="Day 6 DP,";						fileData+=floatData[33]; fileData+="\n";
		fileData+="Day 7 DP,";						fileData+=floatData[34]; fileData+="\n";
		fileData+="Day 8 DP,";						fileData+=floatData[35]; fileData+="\n";
		fileData+="Day 9 DP,";						fileData+=floatData[36]; fileData+="\n";
		fileData+="Day 10 DP,";						fileData+=floatData[37]; fileData+="\n";
		fileData+="Day 11 DP,";						fileData+=floatData[38]; fileData+="\n";
		fileData+="Day 12 DP,";						fileData+=floatData[39]; fileData+="\n";
		fileData+="Day 13 DP,";						fileData+=floatData[40]; fileData+="\n";
		fileData+="Day 14 DP,";						fileData+=floatData[41]; fileData+="\n";
		return fileData;
	}

	public void writeFile(float[] floatData, int32[] int32Data) {
		FileOutputStream fos;
		String fileData="";
		try {
			fos = openFileOutput("undefined.csv", Context.MODE_PRIVATE);
			fileData=formatToString(floatData, int32Data);
			fos.write(fileData.getBytes());
			fos.flush();
			fos.close();
		} catch (IOException e) {
			tvDisplayData.append(e.toString());
		}
	}
	
	public byte[] readFile(String fileName) {
		FileInputStream fis;
		int numBytes=0;
		byte[] buffer = new byte[1024*24];
		try{ 
			fis=new FileInputStream(fileName);
			numBytes = fis.read(buffer);
		} catch(IOException e) {
			
		}
		byte[] readBytes = new byte[numBytes];
		for(int i=0; i<numBytes; i++) {
			readBytes[i]=buffer[i];
		}
		return readBytes;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()){
		case R.id.bRun:
			device= BluetoothSPP.findDevices("G4FC");
			code="0000";
			stationID="TOTALFLOW";
			execute();
			break;
		case R.id.bShare:
			FileOutputStream fos;
			String fileData="";
			try {
				fos = openFileOutput("undefined.csv", Context.MODE_WORLD_READABLE);
				fileData=formatToString(floatData, int32Data);
				fos.write(fileData.getBytes());
				fos.flush();
				fos.close();
			} catch (IOException e) {
			}
			
			Intent sendIntent = new Intent(Intent.ACTION_SEND);
		//	sendIntent.setType("text/plain");
			File filePath = getFileStreamPath("undefined.csv");  //optional //internal storage
			 Intent shareIntent = new Intent();
			 shareIntent.setAction(Intent.ACTION_SEND);
			 shareIntent.putExtra(Intent.EXTRA_STREAM,Uri.fromFile(filePath));  //optional//use this when you want to send an image
			 shareIntent.setType("image/jpeg");
			 shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
			 startActivity(Intent.createChooser(shareIntent, "send"));
			break;
		default :
			tvDisplayData.setText("WHATS HAPPENING");
			break;
			
		}
	}

	   public FileWriter generateCsvFile(File sFileName,String fileContent) {
	        FileWriter writer = null;
	 
	        try {
	            writer = new FileWriter(sFileName);
	            writer.append(fileContent);
	            writer.flush();
	 
	        } catch (IOException e) {

	        }
	        finally {
	            try {
	                writer.close();
	            } catch (IOException e) {
	            }
	        }
	        return writer;
	    }
}
