package com.example.consolesampleandroid;

public class xfRequest {

	private Register Reg;
	private int16 nRegs;
	private int16 rSize;
	
	public xfRequest(int app, int array, int index, int arraySize, int dataSize) {
		setReg(new Register(app,array,index));
		setnRegs(new int16(arraySize));
		rSize=new int16(dataSize);
	}

	public Register getReg() {
		return Reg;
	}

	public void setReg(Register Reg) {
		this.Reg = Reg;
	}

	public int16 getnRegs() {
		return nRegs;
	}

	public void setnRegs(int16 nRegs) {
		this.nRegs = nRegs;
	}
	
	public int16 getrSize() {
		return rSize;
	}
}
