package com.example.consolesampleandroid;

import android.bluetooth.BluetoothDevice;
import android.widget.TextView;

public class xfProtocol implements Runnable {
	
	xfRequestBlock Block;
	private byte[] Code;
	private byte[] StationID;
	private BluetoothSPP Port;
	private BluetoothDevice device;
	private final byte XSINGLE = 0;
	private final byte SIGNLE_CONTROL=1;
	private final byte XREADREQ =0;
	private final byte XDATAXFER=2;
	private final byte XREADY=0;
	private final byte XACK=1;
	private final byte VARIABLE=2;
	final byte SUCCESS=0;
	final byte xfLENERR=(byte) 251;
	final byte xfCRCERR=(byte) 252;
	final byte xfNAKCODE=(byte) 253;
	final byte xfINVALID=(byte) 254;
	final byte xfTIMEOUT=(byte) 255;
	byte finalStatus;
	byte NEWERROR;
	
	private xfFrame _Frame=new xfFrame();
	private xfHeader _Header= new xfHeader();
	private xfRecord _Record=new xfRecord();
	private byte[] returnedData;
	private byte[] departingData;
	private int index;
	private int totalReadBytes;
	private int totalSendBytes;
	private xfRequest[] Request;
	private RegisterData registerData;

	
	public xfProtocol(String Code, String StationID, xfRequest[] registerList, RegisterData registerData, BluetoothDevice device) {
		Block = new xfRequestBlock();
		this.Code = Code.getBytes();
		this.StationID=StationID.getBytes();
		Port = new BluetoothSPP();
		Request = registerList;
		this.registerData=registerData;
		this.device=device;
		
		totalSendBytes=1+4+_Frame.memorySize()+_Header.memorySize()+(_Record.memorySize()+_Record.getCrcMem().length)*(registerData.getNumFloats()+registerData.getNumInt32());
		departingData= new byte[totalSendBytes];
	}
	
	public void run() {
		ReadRegister();
	}
	
	public void ReadRegister() {
		Block.setRequest(Request);
		Block.setCount(new int16(Request.length));
		finalStatus=xfTIMEOUT;
		BluetoothConnect(device);
			SendXFrame();
			SendXHeader(XSINGLE, XREADREQ);
			SendXRecords();
			if(SendAllXData()) {
				finalStatus = ReadAllXData();
				if(finalStatus==SUCCESS) {
					finalStatus = ReadXFrame();
					if(finalStatus==SUCCESS) {
						finalStatus=ReadXHeader();
						if(finalStatus==SUCCESS) {
							finalStatus=ReadXRecords(registerData);
						}
					}
				}
			}
		BluetoothDisconnect();
	}
	
	private boolean SendAllXData() {
		boolean ret;
		if(PortWrite(departingData, departingData.length)==totalSendBytes){
			ret= true;
		} else {
			ret= false;
		}
		return ret;
	}

	private byte ReadAllXData() {
		byte ret;
		totalReadBytes= 1+_Frame.memorySize()+_Header.memorySize();
		for(int i=0; i<Block.getRequest().length; i++) {
			totalReadBytes+=_Record.memorySize()+_Record.getCrcMem().length+ (Block.getRequest()[i].getrSize().intValue()*Block.getRequest()[i].getnRegs().intValue());
		}
		int readIn = PortRead(totalReadBytes);
		returnedData=Port.getReturningData();
		if(readIn==totalReadBytes) {
			ret= SUCCESS;
		} else if(returnedData[20]==0x01){
			NEWERROR=returnedData[22];
			ret= NEWERROR;
		} else {
			ret=xfTIMEOUT;
		}
		return ret;
	}

	private void BluetoothConnect(BluetoothDevice device) {
		Port.connect(device);
	}
	
	private void BluetoothDisconnect() {
		Port.disconnect();
	}
		
	public void SendXFrame() {
		xfFrame Frame = new xfFrame();
		memset(Frame.getMemory()); 
		Frame.setSoh((byte) 0x01);		Frame.getMemory()[0]=0x01;
		Frame.setCtrl((byte) 0x58);		Frame.getMemory()[11]=0x58;
		Frame.setId(StationID.toString());	for(int i=0; i<10; i++) {
											try {
												Frame.getMemory()[i+1]=StationID[i];
											} catch(IndexOutOfBoundsException e) {
												Frame.getMemory()[i+1]=0x20;
											}
										}
		uint16 crc =  crc16(new uint16(0), Code, Code.length);
		crc= crc16(crc, Frame.getMemory(), Frame.memorySize()-2);
		Frame.setFcs(byteSwap(crc));
		Frame.getMemory()[13]=(byte) (Frame.getFcs().and(0x00FF).intValue());
		Frame.getMemory()[14]=(byte) (Frame.getFcs().rightShift(8).intValue());
		
		index=0;
		departingData[index]=(byte)0xff; index++;
		for(int i=0; i<Frame.memorySize(); i++) {
			departingData[index]=Frame.getMemory()[i];
			index++;
		}
		departingData[index]=(byte)0xD3; index++;
		departingData[index]=(byte)0xD9; index++;
		departingData[index]=(byte)0xCE; index++;
		departingData[index]=(byte)0xC3; index++;
	}


	public void SendXHeader(byte hType, byte rType) {
		xfHeader Header = new xfHeader();
		memset(Header.getMemory());
		Header.setNRecs((byte) Block.getCount().intValue());
		Header.getMemory()[0]=0x03;
		Header.getMemory()[1]=0x00;
		Header.getMemory()[2]=(byte) 0xfc;
		Header.getMemory()[3]=(byte) 0xff;
		Header.getMemory()[4]=hType;
		Header.getMemory()[5]=rType;
		Header.getMemory()[6]=Header.getNRecs();
		
		Header.setCrc(crc16(new uint16(0), Header.getMemory(), Header.memorySize()-2));
		Header.getMemory()[7]= Header.getCrc().and(0x00FF).byteValue();
		Header.getMemory()[8]=Header.getCrc().rightShift(8).byteValue();
		
		for(int i=0; i<Header.memorySize(); i++) {
			departingData[index]=Header.getMemory()[i];
			index++;
		}
	}

	public void SendXRecords() {
		for(int i=0; i<Block.getCount().intValue(); i++) {
			xfRecord Record = new xfRecord();
			memset(Record.getMemory());
			Record.setType(VARIABLE);
			Record.setnRegs(new uint16(Block.getRequest()[i].getnRegs().intValue()));
					
			Record.setReg(Block.getRequest()[i].getReg());
			Record.getMemory()[0]=0x0A;
			Record.getMemory()[1]=0x00;
			Record.getMemory()[2]=(byte) 0xF5;
			Record.getMemory()[3]=(byte) 0xFF;
			Record.getMemory()[4]=0x00;
			Record.getMemory()[5]=VARIABLE;
			Record.getMemory()[6]=Record.getReg().app;
			Record.getMemory()[7]=Record.getReg().array;
			Record.getMemory()[8]=(byte)  (Record.getReg().index.intValue() & 0x00FF);
			Record.getMemory()[9]=(byte) (Record.getReg().index.intValue() >> 8);
			Record.getMemory()[10]=(byte) Record.getnRegs().and(0x00FF).intValue();
			Record.getMemory()[11]=(byte)  Record.getnRegs().rightShift(8).intValue();
			Record.getMemory()[12]=0x00;
			Record.getMemory()[13]=0x00;
						
			uint16 crc = crc16(new uint16(0), Record.getMemory(), Record.memorySize());
			Record.getCrcMem()[0]=(byte) (crc.and(0x00FF).intValue());
			Record.getCrcMem()[1]= (byte) (crc.rightShift(8).intValue());
			
			for(int j=0; j<Record.memorySize(); j++) {
				departingData[index]=Record.getMemory()[j];
				index++;
			}
			departingData[index]=Record.getCrcMem()[0]; index++;
			departingData[index]=Record.getCrcMem()[1]; index++;
		}
	}
		
	public byte ReadXFrame() {
		byte ret;
		xfFrame Frame = new xfFrame();
		index=1;
		for(int i=0;i<Frame.memorySize(); i++){
			Frame.getMemory()[i]=returnedData[index];
			index++;
		}
		
		Frame.setFcs(new uint16((Frame.getMemory()[13]<<(8))+Frame.getMemory()[14]));
		uint16 crc = crc16(new uint16(0), Frame.getMemory(), Frame.memorySize()-2);
		if( Frame.getFcs().intValue() == crc.intValue()) {
			ret= SUCCESS;
		} else {
			ret= xfCRCERR;
		}
		return ret;
	}

	public byte ReadXHeader() {
		byte ret=SUCCESS;
		xfHeader Header = new xfHeader();
		for(int i=0;i<Header.memorySize(); i++){
			Header.getMemory()[i]=returnedData[index];
			index++;
		}
		Header.sethType(Header.getMemory()[4]);
		Header.setrType(Header.getMemory()[5]);
		if(Header.getMemory()[0]==~Header.getMemory()[2]) {
			uint16 crc= crc16(new uint16(0), Header.getMemory(), Header.memorySize()-2);
			byte tmp1=(byte) (crc.and(0x00FF).intValue());
			byte tmp2= (byte) (crc.rightShift(8).intValue());
			if(tmp1==Header.getMemory()[7] && tmp2==Header.getMemory()[8]) {
				if(Header.gethType()==XSINGLE) {
					if(Header.getrType()==XDATAXFER) {
						ret= SUCCESS;
					}
				} else {
					ret= xfNAKCODE;
				}
			} else {
				ret= xfCRCERR;
			}
		} else  {
			ret=xfLENERR;
		}
		return ret;
	}

	public byte ReadXRecords(RegisterData registerData) {
		byte Status = SUCCESS;
		int regDataIndex=0;
		for(int i=0; (i<Block.getCount().intValue()) && Status==SUCCESS; i++) {
			xfRecord Record = new xfRecord();
			for(int j=0;j<Record.memorySize(); j++){
				Record.getMemory()[j]=returnedData[index];
				index++;
			}
			
			if(Record.getMemory()[0]==~Record.getMemory()[2]) {
				int Response=Block.getRequest()[i].getrSize().intValue()*Block.getRequest()[i].getnRegs().intValue();
				byte[] tmp = new byte[Block.getRequest()[i].getrSize().intValue()*Block.getRequest()[i].getnRegs().intValue()];
				for(int k=0; k<Response; k++) {
					tmp[k]=returnedData[index];
					registerData.getMemory()[regDataIndex]=returnedData[index];
					regDataIndex++;
					index++;
				}
				
				uint16 crc = crc16(new uint16(0), Record.getMemory(), Record.memorySize());
				crc=crc16(crc, tmp, Response);
				Record.getCrcMem()[0]=returnedData[index]; index++;
				Record.getCrcMem()[1]=returnedData[index]; index++;
				byte tmp1=(byte) (crc.and(0x00FF).intValue());
				byte tmp2= (byte) (crc.rightShift(8).intValue());
				if(Record.getCrcMem()[0]==tmp1 && Record.getCrcMem()[1]==tmp2) {
					
				} else {
					Status=xfCRCERR;
				}
			} else{
				Status=xfLENERR;
			}
		}
		if(index==totalReadBytes-1) {
			Status=xfTIMEOUT;
		}
		return Status;
	}

	private int PortRead(int nBytes) {
		return Port.Read(nBytes);
	}	
	
	private int PortWrite(byte[] Buffer, int nBytes) {
		return Port.Write(Buffer, nBytes);
	}
	
	public static uint16 crc16(uint16 seed, byte[] data, int nbytes) {
		uint16 crcl, crch, re_l, re_h, temp;  
		crcl= seed.and(0x00ff);
		crch= (seed.and(0xff00)).rightShift(8);
		
		for(int i=0; i<nbytes; i++){
			crcl= crcl.xor(data[i]&0x00ff);
		    re_l = ((crcl.leftShift(1)).xor(crcl)).and(0x00ff); 
			crcl = ((re_l.leftShift(2)).xor(re_l)).and(0x00cf);
		    temp = ((crcl.leftShift(4)).xor(crcl)).and(0x00f0);
			re_h = (((temp.and(0x0080)).rightShift(7)).or(temp.leftShift(2))).and(0x00ff);
		    re_l = (((temp.and(0x0040)).leftShift(1)).or(re_l.rightShift(1))).and(0x00ff);
		    re_l = ((re_h.and(0x0001)).leftShift(7)).or(re_l.rightShift(1));		
		    crcl = (crch.xor(re_h)).and(0x00ff);
	    	crch = re_l.and(0x00ff);
		}
		return (crch.leftShift(8)).or(crcl);
	} 
	
	public static uint16 byteSwap(uint16 crc) {
		uint16 returnCrc = null;
		try {
			returnCrc=((crc.rightShift(8)).or(crc.leftShift(8)));
		} catch (NumberFormatException e){
			UInteger crcA = new UInteger(crc.intValue());
			UInteger crcB= crcA.rightShift(8); 
			UInteger crcC =crcA.leftShift(8);
			UInteger crcD = crcB.or(crcC);		
			char[] cd = Integer.toBinaryString(crcD.intValue()).toCharArray();
			String cs="";
			int j=cd.length-1;
			for(int i=0; i<16; i++) {
				cs+=cd[j];
				j--;
			} cs =new StringBuffer(cs).reverse().toString();
			returnCrc=new uint16(Integer.parseInt(cs, 2));
		}
		return returnCrc;
	}

	public static void memset(byte[] frameMemory) {
		for(int i=0; i<frameMemory.length; i++) {
			frameMemory[i]=0x00;
		}
	}
	
}