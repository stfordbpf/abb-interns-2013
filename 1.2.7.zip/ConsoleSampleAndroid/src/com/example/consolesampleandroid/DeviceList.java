package com.example.consolesampleandroid;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.zip.*;

import android.provider.Settings.*;
import android.widget.*;
import android.app.*;
import android.bluetooth.*;
import android.content.*;

/**
 * This Activity appears as a dialog. It lists any paired devices and
 * devices detected in the area after discovery. When a device is chosen
 * by the user, the MAC address of the device is sent back to the parent
 * Activity in the result Intent.
 */
public class DeviceList extends Activity{

	String StationID;
	char[] returnedData;
	BluetoothSocket btSocket;
	BluetoothAdapter btAdapter;
	OutputStream btOut;
	InputStream btIn;
	BluetoothDevice btDevice;
    ArrayList<BluetoothDevice> deviceOptions;

	public DeviceList(String sID) {
        deviceOptions= new ArrayList<BluetoothDevice>();
		StationID=sID;
		btAdapter= BluetoothAdapter.getDefaultAdapter();
		btAdapter.startDiscovery();
		
        if (!btAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 0);
        }
		
        Set<BluetoothDevice> devices = btAdapter.getBondedDevices();
        for (BluetoothDevice device : devices) {
        	deviceOptions.add(device);
        }
        BroadcastReceiver mReceiver = new BroadcastReceiver() {
		    public void onReceive(Context context, Intent intent) {
		        String action = intent.getAction();
		        if (BluetoothDevice.ACTION_FOUND.equals(action)) {
		            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
		            deviceOptions.add(device);
		        }
		    }
		};
		IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
		registerReceiver(mReceiver, filter);

    	for(int i=0; i<deviceOptions.size(); i++) {
			btDevice=deviceOptions.get(i);
    		if(deviceOptions.get(i).getName().equals(StationID)) {
    			break;
    		}
    	}    	
	}
	
	public BluetoothDevice returnDevice() {
		return btDevice;
	}
}
