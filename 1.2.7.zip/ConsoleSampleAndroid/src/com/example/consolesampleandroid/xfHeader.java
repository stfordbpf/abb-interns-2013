package com.example.consolesampleandroid;

public class xfHeader {

    private uint16[] len;
    private byte hType; 
    private byte rType; 
    private byte nRecs; 
	private uint16 crc;
	private byte[] memory;		
	
	public xfHeader() {
		len=new uint16[2];
			len[0]=new uint16(0x0300);
			len[1]=new uint16(0xfcff);
		hType=0;
		rType=0;
		nRecs=0;
		memory= new byte[9];
		crc=new uint16(0);
	}
	
	public int memorySize() {
		return memory.length;
	}

	public byte[] getMemory() {
		return memory;
	}

	public void setCrc(uint16 crc) {
		this.crc=crc;
	}

	public uint16 getCrc() {
		return crc;
	}

	public void setNRecs(byte nRecs) {
		this.nRecs=nRecs;
	}

	public byte getNRecs() {
		return nRecs;
	}

	public uint16[] getLen() {
		return len;
	}

	public void setLen(uint16[] len) {
		this.len = len;
	}

	public byte gethType() {
		return hType;
	}

	public void sethType(byte hType) {
		this.hType = hType;
	}

	public byte getrType() {
		return rType;
	}

	public void setrType(byte rType) {
		this.rType = rType;
	}
}
