package com.example.consolesampleandroid;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.widget.TextView;

public class BluetoothSPP {
    private static final UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothSocket socket;
    private InputStream inStream;
    private OutputStream outStream;
	private byte[] returningData;
	private byte[] outgoingData;
    private static BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
    
    public BluetoothSPP() {
    }


	public void connect(BluetoothDevice device) {
		try {
			socket = device.createRfcommSocketToServiceRecord(uuid);
			socket.connect();
			outStream=socket.getOutputStream();
	        inStream=socket.getInputStream(); 
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}


	public void disconnect() {
		try {
			inStream.close();
			outStream.close();
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public static BluetoothDevice findDevices(String deviceName) {
        adapter = BluetoothAdapter.getDefaultAdapter();
        adapter.startDiscovery();
        Set<BluetoothDevice> devices = adapter.getBondedDevices();
        for (BluetoothDevice device : devices) {
        	if(device.getName().equals(deviceName)) { 
        		adapter.cancelDiscovery();
        		return device;
        	}
        }
        adapter.cancelDiscovery();
		return null;
	}


	public int Read(int nBytes) {
		int index=0;
		int ret=0;
		returningData=new byte[nBytes];	
		do {
		try {
			Thread.sleep(150);
			ret+= inStream.read(returningData);
		} catch (IOException e) {
				ret=0;
			} catch (InterruptedException e) {
			e.printStackTrace();
		} 
		} while(ret<nBytes && returningData[20]!=0x01);
		return ret;
	}


	public int Write(byte[] departingData, int nBytes) {
		outgoingData=departingData;
		int ret;
		try {
			outStream.write(outgoingData, 0, nBytes);
			outStream.flush();
			ret=nBytes;
		} catch (IOException e) {
			e.printStackTrace();
			ret=0;
		} 
		return ret;
	}

	public byte[] getReturningData() {
		return returningData;
	}


}
