package com.example.consolesampleandroid;

public class xfRequestBlock {
	
	private byte Function;
	private int16 Count;
	private xfRequest[] Request;
	
	public xfRequestBlock() {
		Function =0x00;
		Count= null;
		Request = null;
	}
	
	public int16 getCount() {
		return Count;
	}

	public void setCount(int16 Count) {
		this.Count=Count;
	}

	public void setRequest(xfRequest[] Request) {
		this.Request=Request;
	}

	public xfRequest[] getRequest() {
		return Request;
	}
}
