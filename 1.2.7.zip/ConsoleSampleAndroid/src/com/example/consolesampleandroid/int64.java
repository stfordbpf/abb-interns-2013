package com.example.consolesampleandroid;

public class int64 {
	public long value;
	public static int size=8;
	
	public int64(long value) {
		this.value=value;
	}
	
	public static int sizeof() {
		return size;
	}
}
