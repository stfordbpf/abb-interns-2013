package com.example.consolesampleandroid;

public class int32 {
	public int value;
	public static int size=4;
	
	public int32(long value) {
		this.value=(int) value;
	}
	
	public static int sizeof() {
		return size;
	}
}
