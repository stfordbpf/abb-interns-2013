package com.example.consolesampleandroid;

public class RegisterData {

	private float[] fArray;
	private int numFloats;
	private int numInt32;
	private int32[] i32Array;
	private byte[] memory; 
	
	public RegisterData(int arraySize, int numFloats, int numInt32) {
		this.numFloats=numFloats;
		this.numInt32=numInt32;
		fArray=new float[arraySize*numFloats*Float.SIZE/8];
		i32Array= new int32[arraySize*numInt32*int32.sizeof()];
		memory= new byte[fArray.length+i32Array.length];
	}
	
	public int getNumFloats() {
		return numFloats;
	}
	
	public int getNumInt32() {
		return numInt32;
	}
	
	public byte[] getMemory() {
		return memory;
	}
	
	public float[] getfArray() {
		return fArray;
	}

	public int32[] geti32Array() {
		return i32Array;
	}

}
