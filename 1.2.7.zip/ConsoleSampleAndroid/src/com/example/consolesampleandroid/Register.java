package com.example.consolesampleandroid;

public class Register {

	byte app;
	byte array;
	int16 index;
	
	public Register(int app, int array, int index) {
		this.app= (byte)app;
		this.array= (byte)array;
		this.index=new int16(index);
	}
}
