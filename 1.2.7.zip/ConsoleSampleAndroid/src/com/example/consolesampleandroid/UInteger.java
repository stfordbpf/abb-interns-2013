package com.example.consolesampleandroid;


/**
 * The <code>unsigned int</code> type
 *
 * @author Lukas Eder
 */
public final class UInteger extends UNumber implements Comparable<UInteger> {

    /**
     * Generated UID
     */
    private static final long serialVersionUID = -6821055240959745390L;

    /**
     * A constant holding the minimum value an <code>unsigned int</code> can
     * have, 0.
     */
    public static final long  MIN_VALUE        = 0x00000000;

    /**
     * A constant holding the maximum value an <code>unsigned int</code> can
     * have, 2<sup>32</sup>-1.
     */
    public static final long  MAX_VALUE        = 0xffffffffL;

    /**
     * The value modelling the content of this <code>unsigned int</code>
     */
    private final long        value;

    /**
     * Create an <code>unsigned int</code>
     *
     * @throws NumberFormatException If <code>value</code> does not contain a
     *             parsable <code>unsigned int</code>.
     */
    public static UInteger valueOf(String value) throws NumberFormatException {
        return new UInteger(value);
    }

    /**
     * Create an <code>unsigned int</code> by masking it with
     * <code>0xFFFFFFFF</code> i.e. <code>(int) -1</code> becomes
     * <code>(uint) 4294967295</code>
     */
    public static UInteger valueOf(int value) {
        return new UInteger(value);
    }

    /**
     * Create an <code>unsigned int</code>
     *
     * @throws NumberFormatException If <code>value</code> is not in the range
     *             of an <code>unsigned byte</code>
     */
    public static UInteger valueOf(long value) throws NumberFormatException {
        return new UInteger(value);
    }

    /**
     * Create an <code>unsigned int</code>
     *
     * @throws NumberFormatException If <code>value</code> is not in the range
     *             of an <code>unsigned int</code>
     * @deprecated - Use {@link #valueOf(long)}, or {@link Unsigned#uint(long)}
     *             instead
     */
    @Deprecated
    public UInteger(long value) throws NumberFormatException {
        this.value = value;
        rangeCheck();
    }

    /**
     * Create an <code>unsigned int</code> by masking it with
     * <code>0xFFFFFFFF</code> i.e. <code>(int) -1</code> becomes
     * <code>(uint) 4294967295</code>
     *
     * @deprecated - Use {@link #valueOf(int)}, or {@link Unsigned#uint(int)}
     *             instead
     */
    @Deprecated
    public UInteger(int value) {
        this.value = value & MAX_VALUE;
    }

    /**
     * Create an <code>unsigned int</code>
     *
     * @throws NumberFormatException If <code>value</code> does not contain a
     *             parsable <code>unsigned int</code>.
     * @deprecated - Use {@link #valueOf(String)}, or
     *             {@link Unsigned#uint(String)} instead
     */
    @Deprecated
    public UInteger(String value) throws NumberFormatException {
        this.value = Long.parseLong(value);
        rangeCheck();
    }

    private void rangeCheck() throws NumberFormatException {
        if (value < MIN_VALUE || value > MAX_VALUE) {
            throw new NumberFormatException("Value is out of range : " + value);
        }
    }

    @Override
    public int intValue() {
        return (int) value;
    }

    @Override
    public long longValue() {
        return value;
    }

    @Override
    public float floatValue() {
        return value;
    }

    @Override
    public double doubleValue() {
        return value;
    }

    @Override
    public int hashCode() {
        return Long.valueOf(value).hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof UInteger) {
            return value == ((UInteger) obj).value;
        }

        return false;
    }

    @Override
    public String toString() {
        return Long.valueOf(value).toString();
    }

    @Override
    public int compareTo(UInteger o) {
        return (value < o.value ? -1 : (value == o.value ? 0 : 1));
    }
    
    
	public UInteger or(UInteger b) {
    	return new UInteger(this.intValue()|b.intValue());
    }
    public UInteger or(int b){
    	return new UInteger(this.intValue()|b);
    }
    
    public UInteger and(UInteger b) {
    	return new UInteger(this.intValue()&b.intValue());
    }
    public UInteger and(int b){
    	return new UInteger(this.intValue()&b);
    }
    
    public UInteger leftShift(UInteger b) {
    	return new UInteger(this.intValue()<<b.intValue());
    }
    public UInteger leftShift(int b){
    	return new UInteger(this.intValue()<<b);
    }
    
    public UInteger rightShift(UInteger b) {
    	return new UInteger(this.intValue()>>b.intValue());
    }
    public UInteger rightShift(int b){
    	return new UInteger(this.intValue()>>b);
    }
    
    public UInteger xor(UInteger b) {
    	return new UInteger(this.intValue()^b.intValue());
    }
    public UInteger xor(int b) {
    	return new UInteger(this.intValue()^b);
    }
    
    public UInteger not() {
    	return new UInteger(~this.intValue());
    }
}
