package com.example.consolesampleandroid;

public class uint32 extends ULong{

	public uint32(long value) {
		super(value);
	}
	

}
