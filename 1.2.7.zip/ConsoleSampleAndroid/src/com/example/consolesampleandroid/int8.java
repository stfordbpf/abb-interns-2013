package com.example.consolesampleandroid;

public class int8 {
	public byte value;
	public static int size=1;
	
	public int8(long value) {
		this.value=(byte) value;
	}
	
	public static int sizeof() {
		return size;
	}
}
