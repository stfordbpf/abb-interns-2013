package com.example.consolesampleandroid;

public class uint8 extends UByte{

	public uint8(int value) throws NumberFormatException {
		super(value);
	}

}
