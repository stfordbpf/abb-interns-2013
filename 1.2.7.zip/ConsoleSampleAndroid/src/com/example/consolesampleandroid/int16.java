package com.example.consolesampleandroid;

//C++ Signed 16 Bit Integer (signed short int) to java, 
public class int16 {

	private int value;
	public int16(int value) {
		this.value=value;
	}
	
	public static int sizeof() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public int intValue() {
		return value;
	}

	
	
}
